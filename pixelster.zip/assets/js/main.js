;(function ($) {
	
	'use strict';

	$( function() {
        $( "#tabs" ).tabs();
      } );

      $( function() {
        $( "#ta" ).tabs();
      } );

      $( function() {
        $( "#ta-2" ).tabs();
      } );

      $( function() {
        $( "#ta-3" ).tabs();
      } );
      


}(jQuery));